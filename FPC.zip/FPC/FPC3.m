function [U,S,V,numiter]  = FPC3(n)

tau = 1.99;
eta_mu = 1/4;
mu_final = 12;
VERBOSE = 1;
VERBOSE = 2;

tol = 1e-4;

maxiter = 500;

    
if length(n) == 1,
    n1 = n(1); n2 = n1;
elseif length(n) == 2,
    n1 = n(1); n2 = n(2);
end
if n1*n2 < 100*100
    SMALLSCALE = true; 
    X = zeros(n1,n2);
else
    SMALLSCALE = false;
end

[Omega,b] = skm();
m = length(Omega); 
[~,indx] = sort(Omega); 
r = 1; s = r + 1; 
normb = norm(b); 

[i, j] = ind2sub([n1,n2], Omega); 
G = sparse(i,j,b,n1,n2,m); 
mu = normest( G , 1e-2 );

[forwardType, transposeType] = findBestMultiply(G,.2);

U = zeros(n1,1);
V = zeros(n2,1);
S = 0;
relResid = 2;

if VERBOSE, fprintf('**************************************\n'); end
numiter = 0;

while mu > mu_final
    mu = max(mu * eta_mu,mu_final);
    if VERBOSE, fprintf('FPC, mu = %f\n',mu); end
    if VERBOSE == 1, fprintf('\tIteration:      '); end
    s = 2*r + 1;
for k = 1:maxiter
    numiter = numiter + 1; 
    if VERBOSE==1, fprintf('\b\b\b\b%4d',k);  end
    Gt = G';
    switch forwardType
        case 1, Gforward = @(x) G*x;
        case 2, Gforward = @(x) Gt'*x;
        case 3, Gforward = @(x) smvp(G,x);
    end
    switch transposeType 
        case 1, Gtranspose = @(x) Gt*x;
        case 2, Gtranspose = @(x) G'*x;
        case 3, Gtranspose = @(x) smvp(Gt,x);
    end
    Y = @(x) U*(S*(V'*x)) - tau*Gforward(x);
    Yt= @(x) V*(S*(U'*x)) - tau*Gtranspose(x);
    if SMALLSCALE
        [U,Sigma,V] = svd(full(X - tau*G),'econ');
    else
        OK = 0;
        while ~OK
            opts = []; 
            if ~isreal(G), opts.eta = 1e-16; end
            [U,Sigma,V] = lansvd(Y,Yt,n1,n2,s,'L',opts);
            OK = (Sigma(s,s) <= tau*mu) || ( s == min(n1,n2) );
            s = min(2*s, min(n1,n2));
        end
    end
    sigma = diag(Sigma); r = sum(sigma > tau*mu);
    U = U(:,1:r); V = V(:,1:r);
    sigma = sigma(1:r) - tau*mu;
    S = diag(sigma);   
    s = r + 1;
    
    if SMALLSCALE
        X = U*S*V'; x = X(Omega);
    else
        x = XonOmega(U*S,V,Omega);
    end
    resid = x - b;
    try 
        updateSparse(G,resid,indx);
    catch
        l = lasterror;
        if strcmpi( l.identifier, 'MATLAB:UndefinedFunction')
            G = updateSparse_slow(G,resid,indx);
        else
            rethrow(lasterror)
        end
    end
  
    old_relResid = relResid;
    relResid = norm(resid)/normb;
    
    if VERBOSE == 2
        fprintf('iteration %4d, rank is %2d, rel. residual is %.1e\n',k,r,relResid);
    end
    if ~rem(k,5)
        if SMALLSCALE
            sigma_max = norm( U*V' - full(G)/mu );
        else
            Y = @(x) U*(V'*x) - (G*x)/mu;
            Yt= @(x) V*(U'*x) - (G'*x)/mu;
            sigma_max = lansvd(Y,Yt,n1,n2,1,'L');
        end
        if sigma_max - 1 < tol
            break
        end
    end
    if k > 1 && ( abs( relResid - old_relResid) / old_relResid ) < tol
        break
    end

    if (relResid > 1e5)
        disp('Divergence!');
        break
    end
    
end
if VERBOSE == 1
    fprintf('\n\tRelative Residual is %.3f%%\n',100*relResid); 
    fprintf('\tRank is %d\n',r);
end

end
