function [A,B] = sk()
data = importdata('datasets/ml-100k/u3.base');
A = [];
B = [];
for i = 1:80000
    A(i) = (data(i,2) - 1) * 943 + data(i,1);
end
for j = 1:80000
    B(j) = data(j,3);
end
end

