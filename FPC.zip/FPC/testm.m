% ����MovieLens1M
function [rmse] = testm()

[U,S,V]  = FPC2([6040 3952]);
X = U * S * V';

data1 = importdata('datasets/ml-1m/test3');
rmse = 0;
for i = 1:200042
    p = (X(data1(i,1),data1(i,2)) - data1(i,3)) * (X(data1(i,1),data1(i,2)) - data1(i,3));
    rmse = rmse + p;
end
rmse = rmse / 200042;
rmse = sqrt(rmse);

end

