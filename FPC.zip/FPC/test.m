% ����MovieLens100K
function [rmse] = test()

[U,S,V]  = FPC1([943 1682]);
X = U * S * V';

data = importdata('datasets/ml-100k/u3.test');
rmse = 0;
for i = 1:20000
    p = (X(data(i,1),data(i,2)) - data(i,3)) * (X(data(i,1),data(i,2)) - data(i,3));
    rmse = rmse + p;
end
rmse = rmse / 20000;
rmse = sqrt(rmse);

end