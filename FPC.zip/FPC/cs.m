% ������ֵ����MovieLens100K��
function [ccc,cc] = cs()
Q = zeros(943,1682);
P = zeros(943,1682);
data = importdata('datasets/ml-100k/u3.base');

for i = 1:80000
    Q(data(i,1),data(i,2)) = data(i,3);
end
for i = 1:80000
    P(data(i,1),data(i,2)) = data(i,3);
end
aa = 0;
bb = 0;
cc = [];
for j = 1:1682
    for i = 1:943
        if Q(i,j) ~= 0
            aa = aa + Q(i,j);
            bb = bb + 1;
        end
    end
    if bb == 0
        cc(j) = 5;
    else
        cc(j) = aa / bb;
        aa = 0;
        bb = 0;
    end
end   
aaa = 0;
bbb = 0;
ccc = [];
for i = 1:943
    for j = 1:1682
        if P(i,j) ~= 0
            aaa = aaa + Q(i,j);
            bbb = bbb + 1;
        end
    end
    if bbb == 0
        ccc(i) = 5;
    else
        ccc(i) = aaa / bbb;
        aaa = 0;
        bbb = 0;
    end
end

end