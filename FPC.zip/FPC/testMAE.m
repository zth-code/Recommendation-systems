% ����MovieLens100K
function [MAE] = testMAE()

[U,S,V]  = FPC1([943 1682]);
X = U * S * V';

data = importdata('datasets/ml-100k/u3.test');
MAE = 0;
for i = 1:20000
    p = X(data(i,1),data(i,2)) - data(i,3);
    if p < 0
        p = -p;
    end
    MAE = MAE + p;
end
MAE = MAE / 20000;

end