% ����MovieLens1M
function [MAE] = testmMAE()

[U,S,V]  = FPC2([6040 3952]);
X = U * S * V';

data = importdata('datasets/ml-1m/test3');
MAE = 0;
for i = 1:200042
    p = X(data(i,1),data(i,2)) - data(i,3);
    if p < 0
        p = -p;
    end
    MAE = MAE + p;
end
MAE = MAE / 200042;

end

