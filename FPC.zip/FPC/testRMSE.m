% ����MovieLens100K
function [RMSE] = testRMSE()

[U,S,V]  = FPC1([943 1682]);
X = U * S * V';

data = importdata('datasets/ml-100k/u3.test');
RMSE = 0;
for i = 1:20000
    p = (X(data(i,1),data(i,2)) - data(i,3)) * (X(data(i,1),data(i,2)) - data(i,3));
    RMSE = RMSE + p;
end
RMSE = RMSE / 20000;
RMSE = sqrt(RMSE);

rmse = 0;
for i = 1:20000
    p = X(data(i,1),data(i,2)) - data(i,3);
    if p < 0
        p = -p;
    end
    rmse = rmse + p;
end
rmse = rmse / 20000;

end