function [A,B] = skm()
data = importdata('datasets/ml-1m/train3');
A = [];
B = [];
for i = 1:800167
    A(i) = (data(i,2) - 1) * 6040 + data(i,1);
end
for j = 1:800167
    B(j) = data(j,3);
end
end

