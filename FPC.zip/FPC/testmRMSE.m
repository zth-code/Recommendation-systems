% ����MovieLens1M
function [RMSE] = testmRMSE()

[U,S,V]  = FPC2([6040 3952]);
X = U * S * V';

data = importdata('datasets/ml-1m/test3');
RMSE = 0;
for i = 1:200042
    p = (X(data(i,1),data(i,2)) - data(i,3)) * (X(data(i,1),data(i,2)) - data(i,3));
    RMSE = RMSE + p;
end
RMSE = RMSE / 200042;
RMSE = sqrt(RMSE);

rmse = 0;
for i = 1:200042
    p = X(data(i,1),data(i,2)) - data(i,3);
    if p < 0
        p = -p;
    end
    rmse = rmse + p;
end
rmse = rmse / 200042;

end

